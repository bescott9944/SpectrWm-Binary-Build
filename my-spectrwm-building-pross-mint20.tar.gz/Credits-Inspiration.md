# Credit's
### People That Inspired Me:
* Everyone I mention here all have great channels with tons and tons of fantastic videos full of information, scripts, How-To, and just plain great videos that help with this ride called Linux! Thank You! All of you! I have learned so much in the last 4 years. Bruce 7/18/2020
* The scripts and project was inspired by a video from The Linux Dabbler YouTube Channel.
> The Linux Dabbler
> * I would like to thank The Linux Dabbler and his channel. I have learned a bunch from his channel. He is very informative and fun to watch.
> *  The Linux Dabbler Channel: https://www.youtube.com/channel/UC3pasXoRUTKPpQaKtlJz62g
> *  The Linux Dabbler's Video that I watched to produce this project.: https://www.youtube.com/watch?v=tYC7qxnjka4

***
> Eznix
> * Eznix Youtube Channel: https://www.youtube.com/channel/UCQrSHD-tv9nkssrD4nNGcMw
> * Eznix has thought me a lot about Linux in general with his videos on Debian, Arch, Scripting and projects he has done. Eznix also allowed me to help with his EZArcher project as a tester. Great Fun! Eznix is very informative and fun to watch as well. Should have been a instructor. I count his as a friend even though we have never met yet. We will someday after 2020 gets it act together!

***
> DistroTube
> * DistroTube's Youtube Channel: https://www.youtube.com/channel/UCVls1GmFKf6WlTraIb_IaJg
> * This guy know his Tiling Window Managers! He has tons of great videos on everything under the sun on Tiling Window Managers and Arch. Well worth the time to watch his videos.

***
> Switched To Linux
> * Switched To Linux's Youtube Channel: https://www.youtube.com/channel/UCoryWpk4QVYKFCJul9KBdyw
> * Tom has ton's of Distro reviews and how weird and wacky stuff too!Tons of fun and great information.

***
> Joe Collins - EzeeLinux
> * Joe Collins - EzeeLinux Youtube Channel: https://www.youtube.com/channel/UCTfabOKD7Yty6sDF4POBVqA
> * This guy has such a way of teaching you about Linux and what it is all about that I switch to Linux because of Joe and his channel! His channel is like all the others in this list, chocked full of scripts, information, and so much more! You can't go wrong with this channel.

***
> OTB - OldTechBloke
> * OTB - OldTechBloke Youtube Channel: https://www.youtube.com/channel/UCCIHOP7e271SIumQgyl6XBQ
> * Last but not least my buddy across the pond OTB! While his channel is small and growing, he has lots of great content on a wide range of stuff including my Spectrwm. :-) I love his RAMBLES, OTB reminds me a a old English philosopher sometimes the way he makes you think! OTB really puts a lot of thought into his videos. Lots of fun too!

***
> TRG - TheRealGeek
> * TRG - TheRealGeek Youtube Channel: https://www.youtube.com/channel/UCP_rsUTYVSUlT1uPiz2sUvg
> * Can't forget my Denmark Geek! TRG is a wacky nerd geek that has a way to make you go What? Then gets ya think Oh! OK... He is a fun, informative inspiring guy that has a way of getting to laugh and teach you too! He does lots of small projects on Linux and Windows. Just a cool person.

***
### Forums
> A small list of great forums that has helped me a bunch.
> * EzeeTalk: https://www.ezeelinux.com/talk/
> * Endeavouros: https://forum.endeavouros.com/
> * 
